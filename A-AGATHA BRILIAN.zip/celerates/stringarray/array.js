// Daftar antrian awal
let antrian = ["ray", "fiki", "fadhilla", "farah"];

// Tambahkan Nabila ke dalam antrian
antrian.push("nabila");

// Tambahkan Maza dan Elsi ke dalam antrian
antrian.push("maza", "elsi");

// Pembeli terakhir tidak jadi antri dan pulang
antrian.pop();

// Pembeli pertama dan kedua sudah mendapatkan belanjaannya
antrian.shift(); // ray
antrian.shift(); // fiki

// Tambahkan pembeli baru Tomi yang nyerobot antrian
antrian.unshift("tomi");

// Cetak hasil akhir antrian
console.log(antrian);