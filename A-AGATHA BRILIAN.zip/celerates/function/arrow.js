const sayHello = (name) => `Hello ${name}!`;

console.log(sayHello("Hagrid")); // Test case
console.log(sayHello("Luna"));   // Test case
