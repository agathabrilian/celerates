function printHeart() {
    console.log("<3");
}

// Call the function to test it
printHeart();
