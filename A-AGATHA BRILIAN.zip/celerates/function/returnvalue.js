function multiply(a, b) {
    return a * b;
}

// Test the function with examples
console.log(multiply(2, 3)); // 6
console.log(multiply(9, 9)); // 81
console.log(multiply(5, 4)); // 20