function tryToUpperCase(input) {
  try {
    // Pastikan input adalah angka positif
    if (typeof input !== 'number' || input < 0) {
      throw new Error('Input harus berupa angka positif');
    }
    // Ubah input ke string dan konversi ke uppercase
    return input.toString().toUpperCase();
  } catch (error) {
    // Tampilkan pesan error di console
    console.error('An error occurred:', error.message);
    // Kembalikan pesan error sebagai output
    return error.message;
  }
}

function processInput() {
  const inputElement = document.getElementById('inputNumber');
  const inputValue = inputElement.value;

  // Pastikan input bukan string kosong
  if (inputValue.trim() === '') {
    document.getElementById('output').textContent = 'Please enter a number.';
    return;
  }

  const result = tryToUpperCase(Number(inputValue));
  document.getElementById('output').textContent = result;
}