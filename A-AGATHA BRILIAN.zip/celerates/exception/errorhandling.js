// Contoh penanganan error menggunakan try/catch dan throw
function handleStringConversion() {
    try {
        let num = 5;
        // Mencoba untuk memanggil fungsi toUpperCase() pada tipe data angka (yang akan menimbulkan error)
        num.toUpperCase();  // Ini akan menghasilkan error karena toUpperCase() hanya untuk string
    } catch (error) {
        // Menangkap error dan menampilkan pesan error
        console.log("An error occurred: " + error.message);
        // Melemparkan error secara manual dengan pesan kustom
        throw new Error("There was an error processing your request.");
    }
}

// Memanggil fungsi untuk menunjukkan error handling
handleStringConversion();
