// Data menu dan stok awal
let menu = [
  { name: "Pasta", stock: 3 },
  { name: "Burger", stock: 0 }, // Contoh item yang habis
  { name: "Salad", stock: 5 },
  { name: "Pizza", stock: 2 },
  { name: "Sushi", stock: 4 }
];

// Render menu ke dalam HTML (hanya nama menu)
function renderMenu() {
  const menuList = document.getElementById("menu-list");
  menuList.innerHTML = ""; // Kosongkan daftar menu

  menu.forEach(item => {
    let listItem = document.createElement("li");
    listItem.textContent = item.name;  // Hanya menampilkan nama menu
    menuList.appendChild(listItem);
  });
}

// Panggil fungsi render saat halaman dimuat
window.onload = renderMenu;

// Fungsi untuk memilih pesanan
function chooseOrder() {
  let orderName = prompt("Masukkan nama menu yang ingin dipesan (contoh: Pasta):");
  
  let menuItem = menu.find(item => item.name.toLowerCase() === orderName.toLowerCase());
  
  if (menuItem) {
    let quantity = parseInt(prompt(`Masukkan jumlah ${menuItem.name} yang ingin dipesan:`), 10);

    if (!isNaN(quantity) && quantity > 0) {
      if (menuItem.stock >= quantity) {
        menuItem.stock -= quantity;

        console.log(`Pesanan ${quantity} ${menuItem.name} berhasil! Sisa stok: ${menuItem.stock}`);
        alert(`Pesanan ${quantity} ${menuItem.name} berhasil! Sisa stok: ${menuItem.stock}`);

        renderMenu(); // Perbarui tampilan stok di menu
      } else {
        alert(`Maaf, stok ${menuItem.name} tidak mencukupi. Sisa stok: ${menuItem.stock}`);
      }
    } else {
      alert("Jumlah pesanan tidak valid.");
    }
  } else {
    alert("Menu tidak ditemukan. Pastikan Anda mengetik nama menu dengan benar.");
  }
}

// Fungsi untuk menampilkan rating akhir
function showFinalRating() {
  alert("Terima kasih atas pesanan dan rating Anda!");
  console.log("Menampilkan rating akhir.");
}
