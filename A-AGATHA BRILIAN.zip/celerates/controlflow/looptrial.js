for (let i = 0; i < 6; i++) {
    console.log("Da ba dee da ba daa");
}
