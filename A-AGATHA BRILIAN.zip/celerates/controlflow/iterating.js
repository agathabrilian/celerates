// Kode perulangan kedua
const people = ["Scooby", "Velma", "Daphne", "Shaggy", "Fred"];
let output2 = "";
for (let i = 0; i < people.length; i++) {
    output2 += people[i].toUpperCase() + "<br>";  // Menambahkan nama yang sudah diubah menjadi kapital
}
document.getElementById("output2").innerHTML = output2; // Menampilkan hasil di div output2