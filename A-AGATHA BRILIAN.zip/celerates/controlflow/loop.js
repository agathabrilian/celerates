// Kode perulangan pertama
let output1 = "";
for (let i = 25; i >= 0; i -= 5) {
    output1 += i + "<br>";  // Menambahkan hasil perulangan ke string
}
document.getElementById("output1").innerHTML = output1; // Menampilkan hasil di div output1
